To Install, run setup.exe in the installer folder.
To uninstall, use Add / Remove programs from the control panel.

Controls:

Keyboard controls:
Up:	keypad up
Down:	keypad down
Left:	keypad left
Right:	keypad right
Shoot:	space

Start: enter
Exit: escape

Xbox 360 / PC 360 controller controls:
Up:	LS up
Down:	LS down
Left:	LS left
Right:	LS right
Shoot:	A

Start: 	Start
Exit:	Back


Thanks for trying Charlie! <3 Knappstar
knappstar.com
info@knappstar.com